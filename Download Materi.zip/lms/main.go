package main
import (
	"io"
	"net/http"
	"os"
	
	"github.com/gin-contrib/static"
	"github.com/gin-gonic/gin"
)

func main() {
	router := NewRouter()
	router.Run(":8080")
}

type Handler struct {
}

type Response struct {
	Status int         `json:"status"`
	Data   interface{} `json:"data"`
}

func NewRouter() *gin.Engine {
	handler := Handler{}
	router := gin.Default()
	router.POST("/upload", handler.FileUpload)
	router.Use(static.Serve("/static", static.LocalFile("./static", false)))
	router.GET("/", func(context *gin.Context) {
		context.JSON(http.StatusOK, "Running")
	})

	return router
}

func (h *Handler) FileUpload(ctx *gin.Context) {
	var response Response
	ctx.Header("Content-Type", "application/json")

	data, header, err := ctx.Request.FormFile("file")
	if err != nil {
		response.Data = err.Error()
		response.Status = http.StatusBadRequest
		ctx.JSON(http.StatusBadRequest, response)
		return
	}
	defer data.Close()
	f, err := os.OpenFile("./static/"+header.Filename, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		response.Data = err.Error()
		response.Status = http.StatusBadRequest
		ctx.JSON(http.StatusBadRequest, response)
		return
	}
	io.Copy(f, data)

	response.Data = "/static/" + header.Filename
	response.Status = http.StatusOK

	ctx.JSON(http.StatusOK, response)
}
