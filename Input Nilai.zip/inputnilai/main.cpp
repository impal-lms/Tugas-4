#include <stdio.h>
int main(){
    int pilih;
    char *nim[13];
    int nilai;

    printf("FORM NILAI \n\n");
    printf("NIM Siswa          : ");
    scanf("%s",&nim);
    printf("\n\n");

    printf("Menu Nilai :\n\n");
    printf(" 1. Input Nilai  \n\n");
    printf(" 2. Delete Nilai   \n\n");
    printf("Pilihan : ");
    scanf("%i",&pilih);
    switch(pilih);
    if(pilih == 1){
        printf(" Input nilai siswa : ");
        scanf("%i",&nilai);
        printf("Nilai siswa berhasil diinputkan");
        scanf("%i",&pilih);
    }else if(pilih == 2){
        printf("1. Nilai dari siswa akan dihapus \n\n");
        printf("2. Cancel \n\n");
        printf("Pilihan : ");
        scanf("%i",&pilih);
        printf("Nilai dari siswa telah berhasil dihapus");
    }
}

